"""
URL configuration for delivery_service project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from rest_framework import routers
from services.views import DeliveryViewSet, DriverViewSet, CompanyViewSet, OfficeViewSet
from django.contrib import admin
router = routers.DefaultRouter()

router.register(r'deliveries', DeliveryViewSet)
router.register(r'drivers', DriverViewSet)
router.register(r'companies', CompanyViewSet)
router.register(r'offices', OfficeViewSet)

from django.urls import include, path
from services import views

urlpatterns = [
    path("", include(router.urls)),
    path("api/", include(router.urls)),
    path("admin/", admin.site.urls),

    # Simulation
    path("deliveries/<int:delivery_id>/simulate/start/", views.start_simulation,  name="start_simulation"),
    path("deliveries/<int:delivery_id>/stream/",         views.stream_delivery,   name="stream_delivery"),
    path("deliveries/<int:delivery_id>/status/",         views.delivery_status,   name="delivery_status"),
]